# Hot-Desking
Book Desk to have meeting with the clients.
